import { Component, OnInit ,ViewChild} from '@angular/core';
import {ServicesService} from '../../auth/services.service';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Followupstatus} from '../../model/followupstatus';
import { MatDialog, MatDialogConfig } from '@angular/material';
import {EditfollowupstatuslistComponent} from '../editfollowupstatuslist/editfollowupstatuslist.component';
import { DeletestatusdataComponent} from '../deletestatusdata/deletestatusdata.component';
import { AddfollowupstatusComponent} from '../addfollowupstatus/addfollowupstatus.component';

@Component({
  selector: 'app-followup-status-list',
  templateUrl: './followup-status-list.component.html',
  styleUrls: ['./followup-status-list.component.css']
})
export class FollowupStatusListComponent implements OnInit {

  followupstatus:Followupstatus[]=[];
  dataSource: MatTableDataSource<Followupstatus>;
  role_type:string;
  show = true;
  delstatus:string;
@ViewChild(MatSort,{static: true}) sort: MatSort;
@ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;

displayedColumns: string[] = ['Srno','status_name','actions'];
  constructor(private ls:ServicesService,public dialog: MatDialog) { }

  ngOnInit() {
    this.role_type=localStorage.getItem('assign_role');
    this.followupstatuslist();
   
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  followupstatuslist()
  {
    this.ls
    .getFolowupstatuslist()
    .subscribe((data: Followupstatus[]) => {
      this.followupstatus = data;
      this.dataSource = new MatTableDataSource(this.followupstatus);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.show = false;
      //console.log(this.followupstatus);
     });
  }
  edit_followupsstatuslist(v)
    {
      //console.log(v);
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='600px';
      dialogConfig1.height='400px';
      
      dialogConfig1.data={id: v};

      const dialogRef = this.dialog.open(EditfollowupstatuslistComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        //console.log(result);
        });
     
    }
    delete_followupstatus(delid)
    {
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='400px';
      dialogConfig1.height='250px';
      
      dialogConfig1.data={msg1:'Confirm',msg:'Do you realy want to delete !!',status:1};

      const dialogRef = this.dialog.open(DeletestatusdataComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        if(result==true)
        {
          this.ls
      .deletefollowupsstatusdata(delid)
      .subscribe((data: any) => {
        this.delstatus = data;
        dialogConfig1.data={msg1:'Succuss',msg:'Your Data Deleted Successfully !!',status:0};
          const dialogRef = this.dialog.open(DeletestatusdataComponent,dialogConfig1);
          this.followupstatuslist();
              });
          
        }
        });
    }
    add_followups_status()
    {
      const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = false;
      dialogConfig1.autoFocus = true;
      
      dialogConfig1.width='600px';
      dialogConfig1.height='400px';
      
      //dialogConfig1.data={id: v};

      const dialogRef = this.dialog.open(AddfollowupstatusComponent,dialogConfig1);
      dialogRef.afterClosed().subscribe(result => {
        //console.log(result);
        });
     

    }

}
