import { Component, OnInit } from '@angular/core';
import {ServicesService} from '../../auth/services.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  rightSideNav = true ;
  user_type:string;
  mat_menu_status=false;
  constructor(private router: Router,private _ls:ServicesService)
   { }

  ngOnInit() {
    this.user_type=localStorage.getItem('user_type');
  }
  show_hide()
  {
    if(this.mat_menu_status == false)
    {
      this.mat_menu_status  = true;
    }
    else{
      this.mat_menu_status  = false;
    } 
  }
  sideNavBtnToggle()
  {
    if(this.rightSideNav == false)
    {
      this.rightSideNav  = true;
    }
    else{
      this.rightSideNav  = false;
    } 
    
}
logout()
  {
    this._ls.logout();
  }

}
