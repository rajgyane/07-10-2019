import { Component, OnInit } from '@angular/core';
import {ServicesService} from '../../auth/services.service';
import  lead  from '../../model/lead';
import { LeadSource} from '../../model/lead-source';
import { Followupstatus} from '../../model/followupstatus';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  Lead:lead[]= [];
  leadsourcedata:LeadSource[]=[];
  lead_sourceid:any[]=[];
  data1_format:string;
  private postsSub: Subscription;
  data_f1:any = [];
  followupstatus:Followupstatus[]=[];
  data_f2:any = [];
  l_followups_status:any=[];
  constructor(private ls:ServicesService,private route: ActivatedRoute,
    private router: Router) { }

    ngOnInit() 
    {
      this.ls
      .getLeadsourcedata()
      .subscribe((data: LeadSource[]) => {
        this.leadsourcedata = data;
        //console.log(this.leadsourcedata);
              });
      
     
      this.postsSub =this.ls
        .getLead()
        .subscribe((data: lead[]) => {
          this.Lead = data;
          console.log(this.Lead);
         for(var obj in this.Lead)
         {
           if(this.Lead[obj].followup.length>0)
           {
                    this.l_followups_status.push(this.Lead[obj].followup[0]['status']);
           }
           for(var obj1 in this.leadsourcedata)
           {
             if(this.Lead[obj]['lead_source']==this.leadsourcedata[obj1]['lead_source_id'])
             {
               let lead_source_name=this.leadsourcedata[obj1]['lead_source_name'];
               this.lead_sourceid.push(lead_source_name);   
             }
           }
          //this.lead_sourceid.push({'gx':this.Lead[obj]['lead_source']});
           
         }
         console.log(this.l_followups_status);
        
           
         for( var ob1 in this.leadsourcedata)
         {
           //console.log(this.leadsourcedata[ob1]['lead_source_name'])
           
           this.data_f1.push([this.leadsourcedata[ob1]['lead_source_name'], this.check_count(this.leadsourcedata[ob1]['lead_source_name'])]);
          }
  
          
      console.log(this.data_f1);
     
      this.ls
      .getFolowupstatuslist()
      .subscribe((data: Followupstatus[]) => {
        this.followupstatus = data;
        //console.log(this.followupstatus);
        for(var ob3 in this.followupstatus)
        {
          this.data_f2.push([this.followupstatus[ob3]['status_name'],this.check_count2(this.followupstatus[ob3]['status_id'])]);
         //console.log(this.followupstatus[ob3]['status_name']);
        }
        //console.log(this.data_f2);
       });
  
          
      });
      
       //console.log(this.l_followups_status);
      
    }
    
    check_count(v)
    {
      let v1=0;
      for( var ob in this.lead_sourceid)
      {
       
        if(this.lead_sourceid[ob]==v)
        {
          v1++;
        }
  
      }
      return v1;
  
    }
    check_count2(v)
    {
      let v1=0;
      //onsole.log(v);
      //console.log(this.l_followups_status.length,'dsadsad1');
      for( var ob33 in this.l_followups_status)
      {
        //console.log('for loop');
        //console.log(this.l_followups_status[ob33],'fffguytuy2');
        if(this.l_followups_status[ob33]==v)
        {
          v1++;
        }
  
      }
      return v1;
    }
    
    title='Lead Source';
    type='PieChart';
    data = (this.data_f1);         
     options = {    
   
    pieHole:0.4
  };
  columnNames = ['Year', 'Source'];
   width = 465;
   height = 400;
  //graph 2
   title1 = 'Lead Followups';
   type1 = 'ColumnChart';
   data1 = (this.data_f2);
   columnNames1 = ['Year', 'Source'];
   options1 = {    
    is3D:true
  };
   width1 = 465;
   height1 = 400;
  
   title2 = 'Lead Source';
   type2 = 'ColumnChart';
   data2 = (this.data_f1);
   columnNames2 = ['Year', 'Source'];
   options2 = {    
    is3D:true
  };
   width2 = 465;
   height2 = 400;
  
   title3 = 'Lead Source';
   type3 = 'LineChart';
   data3 = (this.data_f1);
   columnNames3 = ['Year', 'Source'];
   options3 = {    
    is3D:true
  };
   width3 = 465;
   height3 = 400;
  
  
  

}
