import { Component, OnInit ,ViewChild,Inject} from '@angular/core';

import { ServicesService} from '../../auth/services.service';
import  {List_org}  from '../../model/list_org';
import{ User} from '../../model/user';
import { Module} from '../../model/module';
import { RoleType} from '../../model/role-type';
import { Permission} from '../../model/permission';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { DialogboxComponent } from '../dialogbox/dialogbox.component';
import { MessageboxComponent} from '../messagebox/messagebox.component';

@Component({
  selector: 'app-permission',
  templateUrl: './permission.component.html',
  styleUrls: ['./permission.component.css']
})
export class PermissionComponent implements OnInit {
  list_org:List_org[]= [];
  checkbox_status:boolean;
  
 

  userlist_data:User[]=[];
  modulelist:Module[]=[];
  assign_role:RoleType[]=[];
  permission_data:Permission[]=[];
  permission_status_data:string[]=[];
  permission_status_data12:string[][][] = [[],[],[]];
  mapped:any;
  panelOpenState = false;
  filter = false;
  checked_status:string;
  constructor(private ls:ServicesService,private route: ActivatedRoute,
    private router: Router,public dialog: MatDialog) {
    
    }

  ngOnInit() {
    console.log('');
    console.log('212121');
    this.ls
      .list_org()
      .subscribe((data: List_org[]) => {
        this.list_org = data;
        // console.log(this.list_org,"fsddfds");
        
        
    });
    /*this.ls
        .user_list()
        .subscribe((data: User[]) => {
          this.userlist_data = data;
          console.log(this.userlist_data);
  });*/
  this.ls
      .assign_role_type()
      .subscribe((data: RoleType[]) => {

        
        //const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
        
        this.assign_role = data;
        // console.log(this.assign_role);
        
        
    }); 

  this.ls
        .module_list()
        .subscribe((data: Module[]) => {
          this.modulelist = data;
          // console.log(this.modulelist);
  });

  this.ls
        .permission_list()
        .subscribe((data: Permission[]) => {
          this.permission_data = data;
          //var status=[];
          let scope=[];
          let scope1=[];
          let scope2=[];
          let statusval='';
          for(let orgd of this.list_org ){
            scope1=[];
            for(let roled of this.assign_role){
              for(let mdl of this.modulelist){
               
                for(let pd of this.permission_data){
                  
                 
                  scope[mdl.module_name]=0;
                  if(orgd.org_aliase==pd.org_name && roled.role_id==pd.role_id && mdl.module_id==pd.module_id)
                  {
                    // console.log("abc:");
                  statusval = pd.module_status;
                  //
                  
                  }else{
                    statusval ='0';
                  }
                
                
                  //this.permission_status_data12[roled.role_name]=this.permission_status_data;
                   //console.log( scope1,'aa');
                 }
                 scope[mdl.module_name]= statusval ;
                
              } 
              scope1[roled.role_name]= scope;
                 scope2[orgd.org_aliase]=scope1; 
              
            }
            
          }
          this.permission_status_data=scope2;
      
          
         //console.log(this.permission_data,"aaa");
          //console.log(this.permission_status_data,"aaa");
          
  });
  
 
}

update_status(st){
  this.checkbox_status=false;
  if(st==1)
  {
    this.checkbox_status=true;
  }
  else{
    this.checkbox_status=false;
  }

}
check_visibility(module_id,role_id,org_aliase)
{
  //console.log(module_id,role_id,org_aliase);
  //console.log('ad');
  let status_val:any;
  for(let pd of this.permission_data)
  {
   
    //console.log(pd.module_id + "=" +module_id ,pd.role_id+'='+role_id,pd.org_name+'='+org_aliase);
    if(pd.module_id==module_id && pd.role_id==role_id && pd.org_name==org_aliase)
    {
      if(pd.module_status=="1")
      {
        //console.log(pd.module_status,'true');
              return true;
            // status_val=true;
      }
      else{
        //console.log(pd.module_status,'false');
        //return false;
        status_val=false;  
      }
    }
    else{
      //console.log(pd.module_status,'false2');
      status_val=false; 
    }
   
  }
  return status_val;

}
select_box(modules,role,org,event)
{
  
  
  //console.log('dasfasddfasf',event.checked);
  
  //console.log("module_id"+modules+"role_id"+role+"org_name"+org+'status='+event.checked);
  const dialogConfig1 = new MatDialogConfig();
      dialogConfig1.disableClose = true;
      dialogConfig1.autoFocus = true;
      dialogConfig1.width='280px';
      dialogConfig1.height='180px';
      this.ls.assign_permission(modules,role,org,event.checked).subscribe(res => {

        dialogConfig1.data = {
          
          response_data:res
    
        };
        const dialogRef = this.dialog.open(MessageboxComponent,dialogConfig1);
        //this.status_update = res;
        //console.log(this.status_update);
    });
}

}
