export class LeadSource {
    lead_source_id:String;
    lead_source_name:String;

}
