export class City {
    id:String;
    District:String;
    city_name:String;
    district_id:String;
    pincode:String;
}
